#!/usr/bin/env bash
# =============================================================================
# Cobblemon MMO — Script de gestion
# Usage : bash manage.sh <commande>
# =============================================================================
set -euo pipefail
export KUBECONFIG="/etc/rancher/k3s/k3s.yaml"
NS="cobblemon"

case "${1:-help}" in
  status)
    echo "=== PODS ==="
    kubectl -n $NS get pods -o wide
    echo ""
    echo "=== SERVICES ==="
    kubectl -n $NS get svc
    echo ""
    echo "=== PVC ==="
    kubectl -n $NS get pvc
    ;;
  logs)
    [[ -z "${2:-}" ]] && echo "Usage: manage.sh logs <server-name>" && exit 1
    kubectl -n $NS logs -f "deploy/mc-${2}" --tail=100
    ;;
  rcon)
    [[ -z "${2:-}" ]] && echo "Usage: manage.sh rcon <server-name>" && exit 1
    kubectl -n $NS exec -it "deploy/mc-${2}" -- rcon-cli
    ;;
  restart)
    [[ -z "${2:-}" ]] && echo "Usage: manage.sh restart <server-name>" && exit 1
    kubectl -n $NS rollout restart "deploy/mc-${2}"
    echo "Restart lancé pour mc-${2}"
    ;;
  restart-all)
    kubectl -n $NS rollout restart deploy -l tier=game-server
    echo "Restart de tous les serveurs MC lancé"
    ;;
  stop)
    [[ -z "${2:-}" ]] && echo "Usage: manage.sh stop <server-name>" && exit 1
    kubectl -n $NS scale "deploy/mc-${2}" --replicas=0
    echo "mc-${2} arrêté"
    ;;
  start)
    [[ -z "${2:-}" ]] && echo "Usage: manage.sh start <server-name>" && exit 1
    kubectl -n $NS scale "deploy/mc-${2}" --replicas=1
    echo "mc-${2} démarré"
    ;;
  watch)
    watch -n 2 "kubectl -n $NS get pods -o wide"
    ;;
  credentials)
    NODE_IP=$(hostname -I | awk '{print $1}')
    GRAFANA_PASS=$(kubectl -n $NS get secret cobblemon-secrets -o jsonpath='{.data.grafana-admin-password}' | base64 -d)
    PG_PASS=$(kubectl -n $NS get secret cobblemon-secrets -o jsonpath='{.data.postgres-password}' | base64 -d)
    RCON_PASS=$(kubectl -n $NS get secret cobblemon-secrets -o jsonpath='{.data.rcon-password}' | base64 -d)
    VEL_SECRET=$(kubectl -n $NS get secret cobblemon-secrets -o jsonpath='{.data.velocity-forwarding-secret}' | base64 -d)
    echo "Minecraft :       ${NODE_IP}:25565"
    echo "Grafana :          http://${NODE_IP}:30090  (admin / ${GRAFANA_PASS})"
    echo "PostgreSQL pass :  ${PG_PASS}"
    echo "RCON pass :        ${RCON_PASS}"
    echo "Velocity secret :  ${VEL_SECRET}"
    ;;
  destroy)
    read -p "Cela supprime tous les pods (PVC conservés). Continuer ? [y/N] " -n 1 -r
    echo
    [[ ! $REPLY =~ ^[Yy]$ ]] && exit 0
    DEPLOY_DIR="$(cd "$(dirname "$0")" && pwd)"
    kubectl delete -f "${DEPLOY_DIR}/kubernetes/05-monitoring.yaml" --ignore-not-found
    kubectl delete -f "${DEPLOY_DIR}/kubernetes/04-mc-servers.yaml" --ignore-not-found
    kubectl delete -f "${DEPLOY_DIR}/kubernetes/03-velocity.yaml" --ignore-not-found
    kubectl delete -f "${DEPLOY_DIR}/kubernetes/02-backend.yaml" --ignore-not-found
    echo "Stack supprimée. Les PVC (données) sont conservés."
    ;;
  redeploy)
    DEPLOY_DIR="$(cd "$(dirname "$0")" && pwd)"
    kubectl apply -f "${DEPLOY_DIR}/kubernetes/02-backend.yaml"
    kubectl apply -f "${DEPLOY_DIR}/kubernetes/03-velocity.yaml"
    kubectl apply -f "${DEPLOY_DIR}/kubernetes/04-mc-servers.yaml"
    kubectl apply -f "${DEPLOY_DIR}/kubernetes/05-monitoring.yaml"
    echo "Stack redéployée."
    ;;
  help|*)
    echo "Cobblemon MMO — Commandes de gestion"
    echo ""
    echo "  status              Voir l'état des pods, services, PVC"
    echo "  watch               Suivi temps réel des pods"
    echo "  logs <server>       Logs d'un serveur (hub, region-1, pvp...)"
    echo "  rcon <server>       Console RCON d'un serveur"
    echo "  restart <server>    Redémarrer un serveur"
    echo "  restart-all         Redémarrer tous les serveurs MC"
    echo "  stop <server>       Arrêter un serveur (scale 0)"
    echo "  start <server>      Démarrer un serveur (scale 1)"
    echo "  credentials         Afficher les mots de passe"
    echo "  redeploy            Réappliquer tous les manifests"
    echo "  destroy             Supprimer la stack (PVC conservés)"
    ;;
esac
