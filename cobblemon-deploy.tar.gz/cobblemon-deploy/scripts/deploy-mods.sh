#!/usr/bin/env bash
# =============================================================================
# Cobblemon MMO — Déploiement des mods
# =============================================================================
# Ce script :
#   1. Met à jour le ConfigMap avec tous les mods Modrinth
#   2. Met à jour les initContainers pour configurer InvSync avec PostgreSQL
#   3. Restart tous les serveurs MC
# =============================================================================

set -euo pipefail
export KUBECONFIG="/etc/rancher/k3s/k3s.yaml"
NS="cobblemon"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
log()  { echo -e "${CYAN}[$(date +%H:%M:%S)]${NC} $*"; }
ok()   { echo -e "${GREEN}[✓]${NC} $*"; }

# ======================== ÉTAPE 1 : MODS ========================
log "ÉTAPE 1 — Mise à jour des mods dans le ConfigMap"

kubectl -n $NS patch configmap mc-common-config --type='merge' -p='{
  "data": {
    "MODRINTH_PROJECTS": "fabricproxy-lite,fabric-api,cobblemon,cobblemon-mega-showdown,accessories,architectury-api,owo-lib,lithium,ferrite-core,mr-invsync"
  }
}'
ok "ConfigMap mis à jour avec tous les mods"

# ======================== ÉTAPE 2 : RÉCUP CREDENTIALS PG ========================
log "ÉTAPE 2 — Récupération des credentials PostgreSQL"

PG_USER=$(kubectl -n $NS get secret cobblemon-secrets -o jsonpath='{.data.postgres-user}' | base64 -d)
PG_PASS=$(kubectl -n $NS get secret cobblemon-secrets -o jsonpath='{.data.postgres-password}' | base64 -d)
PG_DB=$(kubectl -n $NS get secret cobblemon-secrets -o jsonpath='{.data.postgres-db}' | base64 -d)
PG_HOST="postgres.cobblemon.svc.cluster.local"
VEL_SECRET=$(kubectl -n $NS get secret cobblemon-secrets -o jsonpath='{.data.velocity-forwarding-secret}' | base64 -d)

ok "Credentials récupérés (user: $PG_USER, db: $PG_DB, host: $PG_HOST)"

# ======================== ÉTAPE 3 : CRÉER LA BDD INVSYNC ========================
log "ÉTAPE 3 — Création de la base InvSync dans PostgreSQL"

kubectl -n $NS exec deploy/postgres -- psql -U "$PG_USER" -d "$PG_DB" -c "
  CREATE SCHEMA IF NOT EXISTS invsync;
" 2>/dev/null || true
ok "Schema invsync prêt"

# ======================== ÉTAPE 4 : CONFIGMAP INVSYNC ========================
log "ÉTAPE 4 — Création du ConfigMap InvSync"

cat <<INVSYNC | kubectl -n $NS apply -f -
apiVersion: v1
kind: ConfigMap
metadata:
  name: invsync-config
  namespace: $NS
data:
  mr-invsync.json: |
    {
      "database": {
        "type": "POSTGRES",
        "host": "$PG_HOST",
        "port": 5432,
        "database": "$PG_DB",
        "username": "$PG_USER",
        "password": "$PG_PASS"
      },
      "sync": {
        "inventory": true,
        "ender_chest": true,
        "health": true,
        "food": true,
        "experience": true,
        "score": true,
        "status_effects": true,
        "advancements": true,
        "selected_slot": true
      }
    }
INVSYNC

ok "ConfigMap InvSync créé"

# ======================== ÉTAPE 5 : METTRE À JOUR LES DEPLOYMENTS ========================
log "ÉTAPE 5 — Mise à jour de tous les Deployments MC"

# Liste de tous les serveurs avec leur PVC et config
declare -A SERVERS=(
  ["mc-hub"]="pvc-hub|4G|hub|Cobblemon MMO — Hub|100|peaceful|false"
  ["mc-region-1"]="pvc-region-1|6G|region-1|Cobblemon MMO — Région 1|80|hard|true"
  ["mc-region-2"]="pvc-region-2|6G|region-2|Cobblemon MMO — Région 2|80|hard|true"
  ["mc-region-3"]="pvc-region-3|6G|region-3|Cobblemon MMO — Région 3|80|hard|true"
  ["mc-resource-1"]="pvc-resource-1|4G|resource-1|Cobblemon MMO — Ressources 1|60|hard|true"
  ["mc-resource-2"]="pvc-resource-2|4G|resource-2|Cobblemon MMO — Ressources 2|60|hard|true"
  ["mc-resource-3"]="pvc-resource-3|4G|resource-3|Cobblemon MMO — Ressources 3|60|hard|true"
  ["mc-dungeon"]="pvc-dungeon|6G|dungeon|Cobblemon MMO — Donjons|60|hard|true"
  ["mc-pvp"]="pvc-pvp|3G|pvp|Cobblemon MMO — PvP|40|normal|false"
  ["mc-event"]="pvc-event|3G|event|Cobblemon MMO — Événements|60|normal|false"
)

for DEPLOY in "${!SERVERS[@]}"; do
  IFS='|' read -r PVC MEMORY NAME MOTD MAXP DIFF MONSTERS <<< "${SERVERS[$DEPLOY]}"
  APP="${DEPLOY}"
  
  # Déterminer les resources requests/limits
  MEM_REQ="${MEMORY%G}Gi"
  MEM_LIMIT="$((${MEMORY%G} + 1))Gi"
  CPU_REQ="1000m"
  if [[ "${MEMORY%G}" -ge 6 ]]; then CPU_REQ="1500m"; fi

  log "  → Mise à jour $DEPLOY..."

  cat <<YAML | kubectl -n $NS apply -f -
apiVersion: apps/v1
kind: Deployment
metadata:
  name: $DEPLOY
  namespace: $NS
  labels:
    app: $APP
    tier: game-server
    mc-type: ${NAME%%-*}
spec:
  replicas: 1
  strategy:
    type: Recreate
  selector:
    matchLabels:
      app: $APP
  template:
    metadata:
      labels:
        app: $APP
        tier: game-server
        mc-type: ${NAME%%-*}
    spec:
      initContainers:
        # 1. Injecter le secret FabricProxy-Lite
        - name: inject-velocity-secret
          image: busybox:latest
          command:
            - sh
            - -c
            - |
              mkdir -p /data/config
              cat > /data/config/FabricProxy-Lite.toml <<EOF
              hackOnlineMode = true
              hackEarlySend = false
              hackMessageChain = true
              secret = "\$VELOCITY_SECRET"
              EOF
          env:
            - name: VELOCITY_SECRET
              valueFrom:
                secretKeyRef:
                  name: cobblemon-secrets
                  key: velocity-forwarding-secret
          volumeMounts:
            - { name: data, mountPath: /data }
        # 2. Injecter la config InvSync
        - name: inject-invsync-config
          image: busybox:latest
          command:
            - sh
            - -c
            - |
              mkdir -p /data/config
              cp /invsync-config/mr-invsync.json /data/config/mr-invsync.json
              echo "InvSync config injected"
          volumeMounts:
            - { name: data, mountPath: /data }
            - { name: invsync-config, mountPath: /invsync-config }
      containers:
        - name: minecraft
          image: itzg/minecraft-server:latest
          envFrom:
            - configMapRef:
                name: mc-common-config
          env:
            - { name: MEMORY, value: "$MEMORY" }
            - { name: SERVER_NAME, value: "$NAME" }
            - { name: MOTD, value: "$MOTD" }
            - { name: MAX_PLAYERS, value: "$MAXP" }
            - { name: DIFFICULTY, value: "$DIFF" }
            - { name: SPAWN_MONSTERS, value: "$MONSTERS" }
            - name: RCON_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: cobblemon-secrets
                  key: rcon-password
          ports:
            - { containerPort: 25565, name: mc }
            - { containerPort: 25575, name: rcon }
          startupProbe:
            exec:
              command: ["mc-health"]
            initialDelaySeconds: 30
            periodSeconds: 10
            failureThreshold: 120
          readinessProbe:
            exec:
              command: ["mc-health"]
            initialDelaySeconds: 60
            periodSeconds: 15
          livenessProbe:
            exec:
              command: ["mc-health"]
            initialDelaySeconds: 180
            periodSeconds: 30
            failureThreshold: 5
          resources:
            requests:
              memory: "$MEM_REQ"
              cpu: "$CPU_REQ"
            limits:
              memory: "$MEM_LIMIT"
          volumeMounts:
            - { name: data, mountPath: /data }
      volumes:
        - name: data
          persistentVolumeClaim:
            claimName: $PVC
        - name: invsync-config
          configMap:
            name: invsync-config
      terminationGracePeriodSeconds: 60
YAML
done

ok "Tous les Deployments mis à jour"

# ======================== ÉTAPE 6 : SERVICES (s'assurer qu'ils existent) ========================
log "ÉTAPE 6 — Vérification des Services"

for DEPLOY in "${!SERVERS[@]}"; do
  IFS='|' read -r PVC MEMORY NAME MOTD MAXP DIFF MONSTERS <<< "${SERVERS[$DEPLOY]}"
  
  cat <<YAML | kubectl -n $NS apply -f -
apiVersion: v1
kind: Service
metadata:
  name: $DEPLOY
  namespace: $NS
spec:
  type: ClusterIP
  selector:
    app: $DEPLOY
  ports:
    - { port: 25565, targetPort: 25565, name: mc }
    - { port: 25575, targetPort: 25575, name: rcon }
YAML
done

ok "Services vérifiés"

# ======================== ÉTAPE 7 : ATTENTE ========================
log "ÉTAPE 7 — Démarrage des serveurs"

echo ""
echo -e "${YELLOW}Les serveurs téléchargent les mods (~200 Mo chacun) et démarrent.${NC}"
echo -e "${YELLOW}Cobblemon est un gros mod, comptez 5-10 minutes pour le premier démarrage.${NC}"
echo -e "${YELLOW}Le startupProbe donne jusqu'à 20 minutes avant de considérer un échec.${NC}"
echo ""

log "Suivi en temps réel (Ctrl+C pour quitter le suivi) :"
timeout 60 kubectl -n $NS get pods -l tier=game-server -w 2>/dev/null || true

echo ""
echo "============================================"
echo -e "${GREEN}    DÉPLOIEMENT DES MODS TERMINÉ${NC}"
echo "============================================"
echo ""
echo "Mods installés sur les 10 serveurs :"
echo "  - Cobblemon (Pokémon)"
echo "  - Mega Showdown (Méga-évo, Z-Moves, Dynamax, Téracristal)"
echo "  - Lithium + FerriteCore (optimisation)"
echo "  - MR InvSync (sync inventaires via PostgreSQL)"
echo "  - FabricProxy-Lite (forwarding Velocity)"
echo ""
echo "Vérification :"
echo "  kubectl -n cobblemon get pods          # Tous les pods"
echo "  kubectl -n cobblemon logs deploy/mc-hub | grep -i cobblemon  # Vérifier Cobblemon charge"
echo "  kubectl -n cobblemon logs deploy/mc-hub | grep -i invsync    # Vérifier InvSync charge"
echo ""
echo -e "${YELLOW}IMPORTANT pour les joueurs :${NC}"
echo "  Les joueurs doivent installer côté client :"
echo "  - Cobblemon (même version que le serveur)"
echo "  - Mega Showdown + ses dépendances"
echo "  - Fabric API"
echo "  - Optionnel : Sodium, Xaero's Minimap, EMI, Mouse Tweaks"
echo ""
