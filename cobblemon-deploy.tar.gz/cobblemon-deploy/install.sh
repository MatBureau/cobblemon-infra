#!/usr/bin/env bash
# =============================================================================
# Cobblemon MMO — Script d'installation complet
# =============================================================================
# Ce script déploie toute l'infra sur un Debian 13 vierge :
#   1. Installe Ansible
#   2. Provisionne le serveur + installe K3s via Ansible
#   3. Déploie tous les manifests Kubernetes (Velocity, 10 MC, PG, Redis, Grafana)
#
# Usage : sudo bash install.sh
# =============================================================================

set -euo pipefail

# ======================== CONFIG ========================
export KUBECONFIG="/etc/rancher/k3s/k3s.yaml"
DEPLOY_DIR="$(cd "$(dirname "$0")" && pwd)"
K8S_DIR="${DEPLOY_DIR}/kubernetes"
ANSIBLE_DIR="${DEPLOY_DIR}/ansible"
NAMESPACE="cobblemon"

# Couleurs
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

log()  { echo -e "${CYAN}[$(date +%H:%M:%S)]${NC} $*"; }
ok()   { echo -e "${GREEN}[✓]${NC} $*"; }
warn() { echo -e "${YELLOW}[!]${NC} $*"; }
err()  { echo -e "${RED}[✗]${NC} $*"; exit 1; }

# ======================== CHECKS ========================
[[ $EUID -ne 0 ]] && err "Ce script doit être lancé en root (sudo bash install.sh)"

log "Cobblemon MMO — Déploiement infrastructure"
log "============================================"
echo ""

# ======================== ÉTAPE 1 : ANSIBLE ========================
log "ÉTAPE 1/6 — Installation d'Ansible"

if command -v ansible-playbook &>/dev/null; then
    ok "Ansible déjà installé ($(ansible --version | head -1))"
else
    apt-get update -qq
    apt-get install -y -qq python3 python3-pip python3-venv sshpass git curl wget jq > /dev/null 2>&1
    pip3 install --break-system-packages ansible > /dev/null 2>&1
    ok "Ansible installé"
fi

# ======================== ÉTAPE 2 : ANSIBLE PLAYBOOK ========================
log "ÉTAPE 2/6 — Provisioning du serveur + installation K3s"

cd "${ANSIBLE_DIR}"
ansible-playbook -i inventory/hosts.yml provision.yml -v

ok "K3s installé et serveur configuré"

# Attendre que K3s soit complètement prêt
log "Attente de K3s..."
for i in $(seq 1 60); do
    if kubectl get nodes &>/dev/null; then
        break
    fi
    sleep 2
done
kubectl wait --for=condition=Ready node --all --timeout=120s
ok "K3s prêt"

# ======================== ÉTAPE 3 : SECRETS ========================
log "ÉTAPE 3/6 — Génération des secrets"

# Générer un forwarding secret aléatoire pour Velocity <-> MC servers
VELOCITY_SECRET=$(openssl rand -hex 32)

# Créer le namespace
kubectl apply -f "${K8S_DIR}/00-namespace.yaml"

# Créer le secret Kubernetes
kubectl -n ${NAMESPACE} create secret generic cobblemon-secrets \
    --from-literal=velocity-forwarding-secret="${VELOCITY_SECRET}" \
    --from-literal=postgres-user="cobblemon" \
    --from-literal=postgres-password="$(openssl rand -hex 16)" \
    --from-literal=postgres-db="cobblemon_db" \
    --from-literal=rcon-password="$(openssl rand -hex 12)" \
    --from-literal=grafana-admin-password="$(openssl rand -hex 12)" \
    --dry-run=client -o yaml | kubectl apply -f -

ok "Secrets générés et stockés dans Kubernetes"

# ======================== ÉTAPE 4 : STOCKAGE ========================
log "ÉTAPE 4/6 — Création des volumes persistants"

kubectl apply -f "${K8S_DIR}/01-storage.yaml"
ok "PVCs créés"

# ======================== ÉTAPE 5 : DÉPLOIEMENT ========================
log "ÉTAPE 5/6 — Déploiement de la stack"

# Ordre important : backend d'abord, puis les serveurs MC, puis le proxy
log "  → Backend (PostgreSQL + Redis)..."
kubectl apply -f "${K8S_DIR}/02-backend.yaml"

# Attendre que PG et Redis soient up avant de lancer le reste
log "  → Attente PostgreSQL et Redis..."
kubectl -n ${NAMESPACE} wait --for=condition=Ready pod -l app=postgres --timeout=120s 2>/dev/null || true
kubectl -n ${NAMESPACE} wait --for=condition=Ready pod -l app=redis --timeout=120s 2>/dev/null || true

log "  → Velocity Proxy..."
kubectl apply -f "${K8S_DIR}/03-velocity.yaml"

log "  → Serveurs Minecraft (10 mondes)..."
kubectl apply -f "${K8S_DIR}/04-mc-servers.yaml"

log "  → Monitoring (Prometheus + Grafana)..."
kubectl apply -f "${K8S_DIR}/05-monitoring.yaml"

ok "Tous les manifests appliqués"

# ======================== ÉTAPE 6 : ATTENTE & STATUS ========================
log "ÉTAPE 6/6 — Attente du démarrage des pods"

echo ""
log "Les serveurs MC moddés mettent 2-5 minutes à démarrer..."
log "Suivi en temps réel (Ctrl+C pour quitter le suivi, le déploiement continue) :"
echo ""

# Afficher le statut pendant 30s puis le résumé final
timeout 30 kubectl -n ${NAMESPACE} get pods -w 2>/dev/null || true

echo ""
echo "============================================"
echo -e "${GREEN}    DÉPLOIEMENT TERMINÉ${NC}"
echo "============================================"
echo ""

# Récupérer les mots de passe
GRAFANA_PASS=$(kubectl -n ${NAMESPACE} get secret cobblemon-secrets -o jsonpath='{.data.grafana-admin-password}' | base64 -d)
PG_PASS=$(kubectl -n ${NAMESPACE} get secret cobblemon-secrets -o jsonpath='{.data.postgres-password}' | base64 -d)
RCON_PASS=$(kubectl -n ${NAMESPACE} get secret cobblemon-secrets -o jsonpath='{.data.rcon-password}' | base64 -d)
NODE_IP=$(hostname -I | awk '{print $1}')

echo -e "${CYAN}Accès Minecraft :${NC}  ${NODE_IP}:25565"
echo -e "${CYAN}Accès Grafana :${NC}    http://${NODE_IP}:30090  (admin / ${GRAFANA_PASS})"
echo ""
echo -e "${CYAN}Mot de passe PostgreSQL :${NC}  ${PG_PASS}"
echo -e "${CYAN}Mot de passe RCON :${NC}        ${RCON_PASS}"
echo -e "${CYAN}Velocity Secret :${NC}          ${VELOCITY_SECRET}"
echo ""
echo -e "${YELLOW}Commandes utiles :${NC}"
echo "  kubectl -n cobblemon get pods            # Voir les pods"
echo "  kubectl -n cobblemon logs -f deploy/mc-hub  # Logs du Hub"
echo "  kubectl -n cobblemon exec -it deploy/mc-hub -- rcon-cli  # Console RCON"
echo ""
echo -e "${YELLOW}IMPORTANT :${NC}"
echo "  Les serveurs sont en Fabric vanilla. Pour Cobblemon :"
echo "  1. Ajoutez vos mods dans les volumes (/opt/cobblemon/data/<server>/mods/)"
echo "  2. Ajoutez FabricProxy-Lite pour le forwarding Velocity"
echo "  3. Restart : kubectl -n cobblemon rollout restart deploy/mc-hub"
echo ""

# Sauvegarder les credentials
cat > "${DEPLOY_DIR}/credentials.txt" <<EOF
# Cobblemon MMO — Credentials (GARDEZ CE FICHIER EN SÉCURITÉ)
# Généré le $(date)

MINECRAFT_ADDRESS=${NODE_IP}:25565
GRAFANA_URL=http://${NODE_IP}:30090
GRAFANA_USER=admin
GRAFANA_PASSWORD=${GRAFANA_PASS}
POSTGRES_PASSWORD=${PG_PASS}
RCON_PASSWORD=${RCON_PASS}
VELOCITY_SECRET=${VELOCITY_SECRET}
KUBECONFIG=/etc/rancher/k3s/k3s.yaml
EOF

chmod 600 "${DEPLOY_DIR}/credentials.txt"
ok "Credentials sauvegardés dans ${DEPLOY_DIR}/credentials.txt"
